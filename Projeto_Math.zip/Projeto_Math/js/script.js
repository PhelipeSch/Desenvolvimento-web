
/*
let nr = parseInt( prompt('Digite a quantidade de números:') );

for (let i = 0; i < nr; i++) {
    let v = Math.random() * 60;
    document.write('<h1>' + Math.ceil(v) + '<\h1>');
    console.log(v);
}

let valor = 10.256;

document.write('<p>' + valor.toFixed(2) + '<\p>');


let email = 'ernani@gmail.com';
document.write ( '<h2>' + email.indexOf('#') + '<\h2>');
*/

let mensagem = prompt('Digite o e-mail: ');

if(mensagem.indexOf('@') == -1){
    document.write('<h1 class="inval">'+ 'Email inválido! <\h1>');
}else{
    document.write('<h1 class = "val" >'+ 'Email válido!'+'<\h1>');
}